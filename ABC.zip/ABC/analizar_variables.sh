#!/bin/bash
# =========================================
# Script: analizar_variables.sh
# Objetivo: Demostrar el uso de las variables especiales $-, $!, y $@
# =========================================

echo "===== Análisis de Variables Especiales ====="

# 1. Mostrar los modos actuales de operación del shell
echo ""
echo "1️ Modos de operación actuales del shell:"
set -o          # Muestra los modos activos/desactivados
echo ""
echo "Contenido de \$-:"
echo "$-"

# 2. Ejecutar comandos y capturar el PID del último proceso en segundo plano
echo ""
echo "2️ Ejecutando un comando en segundo plano..."
sleep 5 &       # Proceso en segundo plano (simula un comando largo)
PID=$!          # Captura el PID del último proceso ejecutado en background
echo "PID del proceso en segundo plano: $PID"

# 3. Imprimir todos los argumentos pasados al script
echo ""
echo "3️ Argumentos recibidos por el script (\$@):"
echo "$@"

echo ""
echo "===== Fin del análisis ====="
