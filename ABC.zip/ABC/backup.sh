#!/bin/bash

# Identificar archivos modificados en las últimas 24 horas
modified_files=$(find . -type f -mtime -1)

# Crear un archivo comprimido con los archivos modificados
backup_file="backup_$(date +%Y%m%d).tar.gz"
tar -czf "$backup_file" $modified_files

# Capturar el estado de salida del comando tar
if [[ $? -eq 0 ]]; then
    echo "Backup creado con éxito: $backup_file"
else
    echo "Error al crear el backup."
fi

# Generar un log
log_file="backup_log_$(date +%Y%m%d).txt"
echo "Backup realizado el: $(date)" > "$log_file"
echo "Archivos incluidos:" >> "$log_file"
echo "$modified_files" >> "$log_file"

# Simular el envío de un correo electrónico
echo "Enviando correo electrónico con el backup y el log adjunto..."
# (Esto es solo un simulacro, no se enviará un correo real)
echo "Correo enviado con éxito (simulado)."