#!/bin/bash

# Archivo donde se guardarán las tareas
ARCHIVO="tareas.txt"

# Crear archivo si no existe
touch "$ARCHIVO"

# === Función para agregar una tarea ===
agregar_tarea() {
    echo "Ingresa la descripción de la tarea:"
    read -r tarea
    if [[ -z "$tarea" ]]; then
        echo " No puedes agregar una tarea vacía."
    else
        echo "$tarea" >> "$ARCHIVO"
        echo " Tarea agregada correctamente."
    fi
}

# === Función para listar tareas ===
listar_tareas() {
    if [[ ! -s "$ARCHIVO" ]]; then
        echo " No hay tareas registradas."
    else
        echo " Lista de tareas:"
        nl -w2 -s". " "$ARCHIVO"
    fi
}

# === Función para eliminar una tarea ===
eliminar_tarea() {
    listar_tareas
    echo ""
    echo "Ingresa el número de la tarea que deseas eliminar:"
    read -r num

    if ! [[ "$num" =~ ^[0-9]+$ ]]; then
        echo " Debes ingresar un número válido."
        return
    fi

    total=$(wc -l < "$ARCHIVO")
    if (( num < 1 || num > total )); then
        echo " Número fuera de rango."
        return
    fi

    # Eliminar línea usando sed y guardar en archivo temporal
    sed "${num}d" "$ARCHIVO" > temp.txt && mv temp.txt "$ARCHIVO"
    echo " Tarea número $num eliminada correctamente."
}

# === Menú principal ===
while true; do
    echo ""
    echo "=====  Administrador de Tareas ====="
    echo "1. Agregar tarea"
    echo "2. Listar tareas"
    echo "3. Eliminar tarea"
    echo "4. Salir"
    echo "====================================="
    echo -n "Selecciona una opción (1-4): "
    read -r opcion

    case $opcion in
        1) agregar_tarea ;;
        2) listar_tareas ;;
        3) eliminar_tarea ;;
        4) echo "Saliendo... ¡Hasta pronto!"; break ;;
        *) echo "Opción inválida. Intenta nuevamente." ;;
    esac
done
