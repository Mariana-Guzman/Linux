#!/bin/bash

# Verificar si Bash está en modo de depuración
if [[ $- == *x* ]]; then
    echo "Modo de depuración activado"
fi

# Verificar el número de argumentos
if [[ $# -eq 0 ]]; then
    echo "No se pasaron argumentos."
elif [[ $# -eq 1 && $1 == "start" ]]; then
    echo "Iniciando proceso en segundo plano..."
    sleep 20 &
    echo "Proceso iniciado con PID: $!"
else
    echo "Argumentos no válidos o no se reconocen."
fi
