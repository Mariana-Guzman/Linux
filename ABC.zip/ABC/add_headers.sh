#!/bin/bash

# ==============================
# Script: add_headers.sh
# Descripción: Añade encabezados automáticos a todos los archivos main_*.sh dentro de module_*
# ==============================

# Variable con la fecha actual
FECHA=$(date +"%Y-%m-%d %H:%M:%S")

# Descripción breve que se agregará al inicio de cada archivo
DESCRIPCION="Script principal del módulo."

# Recorrer todos los archivos main_*.sh dentro de module_*
for archivo in Proyecto/src/module_*/main_*.sh; do
    if [ -f "$archivo" ]; then
        echo "Añadiendo encabezado a: $archivo"

        # Crear un encabezado temporal
        encabezado="# =========================================
# Archivo: $(basename "$archivo")
# Fecha de creación: $FECHA
# Descripción: $DESCRIPCION
# =========================================
"

        # Insertar el encabezado al inicio del archivo
        # Usamos un archivo temporal para combinar encabezado + contenido original
        temp_file=$(mktemp)
        echo "$encabezado" > "$temp_file"
        cat "$archivo" >> "$temp_file"
        mv "$temp_file" "$archivo"
    fi
done

echo " Encabezados agregados exitosamente."
